<?php
        include '../user_mangement/custmers/dblink.php';


?>

<html>

        <form action="products_results.php" method="POST">
                <input type="text" name="S_text">
                <input type="submit" name="submit"  value="Search" >
        </form>

        
</html>
